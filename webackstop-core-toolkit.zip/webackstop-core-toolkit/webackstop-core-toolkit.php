<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.

/**
 *
 * Plugin Name: Core Toolkit - Webackstop
 * Plugin URI: http://webackstop.com/
 * Author: Webackstop
 * Author URI: http://webackstop.com/
 * Version: 1.0.0
 * Description: Core Toolkit is a framework to extend the functionality and features of the WordPress Themes developed by Webackstop. Although our themes work fine without this toolkit, but to get full features you must need to activate it.
 * Text Domain: csf
 * Domain Path: /languages
 *
 */

require_once plugin_dir_path( __FILE__ ) .'classes/setup.class.php';
